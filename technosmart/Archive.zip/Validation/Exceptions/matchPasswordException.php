<?php

namespace Technosmart\Validation\Exceptions;

use Respect\Validation\Exceptions\ValidationException;

class matchPasswordException extends ValidationException{
    
    public static $defaultTemplates  = [
        
        self::MODE_DEFAULT => [
            self::STANDARD => 'Your Password doesnot match',
        ],
    ];
    
}
