<?php
namespace Technosmart\Models;
class Register extends BaseModel {

    protected $table = "request";

    protected $fillable = [
      'first_name',
      'last_name',
      'grade',
      'school',
      'age',
      'session',
      'parent_name',
      'email' ,
      'phone',
      'emergency_name',
      'emergency_number',
      'pickup',
      'is_usb',
    ];

    public function session(){
        return $this->hasOne('Technosmart\Models\Session','id','session');
    }
    public function programs(){
      return $this->hasOne('Technosmart\Models\Programs','id','school');
    }
    public function pickup(){
      return $this->hasOne('Technosmart\Models\Pickup','id','pickup');
    }

}
