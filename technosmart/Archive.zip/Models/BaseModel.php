<?php
namespace Technosmart\Models;

use Illuminate\Database\Eloquent\Model;

class BaseModel  extends Model{


}
