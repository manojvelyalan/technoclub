<?php
namespace Technosmart\Models;

class Session extends BaseModel {

    protected $table = "session";

    protected $fillable = [
        'title',
        'status'
    ];

}
