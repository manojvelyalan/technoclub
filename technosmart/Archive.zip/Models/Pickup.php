<?php

namespace Technosmart\Models;

class Pickup extends BaseModel {

    protected $table = "pickup";

    protected $fillable = [
       'title',
    ];

}
