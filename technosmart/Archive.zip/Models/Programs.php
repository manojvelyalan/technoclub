<?php
namespace Technosmart\Models;
class Programs extends BaseModel{

 protected $table = 'programs';
 protected $fillable = [
    'programs',
    'day',
    'start_month',
    'end_month',
    'grade',
    'time' ,
    'seat',
    'fee',
    'description',
    'status',
    'date'
 ];

}
